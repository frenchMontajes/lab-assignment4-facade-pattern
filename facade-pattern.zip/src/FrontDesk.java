public class FrontDesk {
    public Valet valet;
    public HouseKeeping houseKeeping;
    public Cart cart;

    public FrontDesk(Valet valet, HouseKeeping houseKeeping, Cart cart) {
       this.valet = valet;
       this.houseKeeping = houseKeeping;
       this.cart = cart;
    }
}
