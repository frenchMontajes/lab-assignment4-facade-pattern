public interface hotelService {
        void getService();
}
